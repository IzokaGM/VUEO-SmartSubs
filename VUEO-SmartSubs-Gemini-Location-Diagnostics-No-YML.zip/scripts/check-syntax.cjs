'use strict'
const {readdirSync} = require('node:fs')
const {join} = require('node:path')
const {spawnSync} = require('node:child_process')
for (const directory of ['src', 'scripts', 'test']) {
 for (const name of readdirSync(directory)) {
  if (!/\.(?:js|mjs|cjs)$/.test(name)) continue
  const result=spawnSync(process.execPath,['--check',join(directory,name)],{stdio:'inherit'})
  if(result.error) throw result.error
  if(result.status!==0) process.exit(result.status || 1)
 }
}
